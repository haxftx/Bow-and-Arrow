#include "Object2D.h"
#include <Core/Engine.h>

Mesh* Object2D::CreateSquare(std::string name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill)
{ // creeaza un patrat
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices =
	{
		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(length, 0, 0), color),
		VertexFormat(corner + glm::vec3(length, length, 0), color),
		VertexFormat(corner + glm::vec3(0, length, 0), color)
	};

	Mesh* square = new Mesh(name);
	std::vector<unsigned short> indices = { 0, 1, 2, 3 };

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);

	return square;
}

Mesh* Object2D::CreateShuriken(std::string name, glm::vec3 leftBottomCorner, float size, glm::vec3 color)
{ // creaza obiectul shuriken
	glm::vec3 corner = leftBottomCorner;
	std::vector<VertexFormat> vertices =
	{
		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(-size , 0, 0), color),
		VertexFormat(corner + glm::vec3(-size * sqrt(3) / 2, size * sqrt(3) / 2, 0), color),

		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(0, size, 0), color),
		VertexFormat(corner + glm::vec3(size * sqrt(3) / 2, size * sqrt(3) / 2, 0), color),

		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(size, 0, 0), color),
		VertexFormat(corner + glm::vec3(size * sqrt(3) / 2, -size * sqrt(3) / 2, 0), color),

		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(0, -size, 0), color),
		VertexFormat(corner + glm::vec3(-size * sqrt(3) / 2, -size * sqrt(3) / 2, 0), color),

	};

	Mesh* shuriken = new Mesh(name);
	std::vector<unsigned short> indices = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };

	shuriken->SetDrawMode(GL_TRIANGLES);
	shuriken->InitFromData(vertices, indices);
	return shuriken;
}

Mesh* Object2D::CreateBow(std::string name, glm::vec3 leftBottomCorner, float radius, glm::vec3 color)
{ // creeaza arcul
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices = {};
	std::vector<unsigned short> indices;
	int i;
	for (i = 0; i < 100; i++) { // semicercul 
		indices.push_back(i);
		float theta = 1.f * M_PI * float(i) / float(100) - M_PI_2;
		float x = radius * cosf(theta);
		float y = radius * sinf(theta);

		vertices.push_back(VertexFormat(corner + glm::vec3(x, y, 0), color));
	}
	
	indices.push_back(0);
	vertices.push_back(vertices[0]);
	Mesh* bow = new Mesh(name);
	
	bow->SetDrawMode(GL_LINE_STRIP);
	bow->InitFromData(vertices, indices);
	return bow;
}

Mesh* Object2D::CreateBall(std::string name, glm::vec3 leftBottomCorner, float radius, glm::vec3 color)
{	// creez un cerc
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices = {};
	std::vector<unsigned short> indices;
	int i;
	for (i = 0; i < 99; i++) {
		indices.push_back(i);
		float theta = 2.f * M_PI * float(i) / float(100);
		float x = radius * cosf(theta);
		float y = radius * sinf(theta);

		vertices.push_back(VertexFormat(corner + glm::vec3(x, y, 0), color));
	}

	Mesh* ball = new Mesh(name);
	ball->SetDrawMode(GL_TRIANGLE_FAN);
	ball->InitFromData(vertices, indices);
	return ball;
}

Mesh* Object2D::CreatePoline(std::string name, glm::vec3 leftBottomCorner, float radius, glm::vec3 color)
{	// creez o polilinie
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices = { 
		VertexFormat(corner + glm::vec3(0, -radius, 0), color),
		VertexFormat(corner + glm::vec3(-radius / 8, -radius - radius / 8, 0), color),
		VertexFormat(corner + glm::vec3(0, -radius - radius / 4, 0), color),
		VertexFormat(corner + glm::vec3(-radius / 8, -radius - radius / 2, 0), color),
	};
	std::vector<unsigned short> indices = {0, 1, 2, 3};

	Mesh* poline = new Mesh(name);
	poline->SetDrawMode(GL_LINE_STRIP);
	poline->InitFromData(vertices, indices);
	return poline;
}

Mesh* Object2D::CreateArow(std::string name)
{	// creez sageata
	glm::vec3 corner = glm::vec3(0);
	glm::vec3 color = glm::vec3(1,1,1);

	std::vector<VertexFormat> vertices =
	{
		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(0, 5, 0), color),
		VertexFormat(corner + glm::vec3(40, 5, 0), color),
		VertexFormat(corner + glm::vec3(40, 10, 0), color),
		VertexFormat(corner + glm::vec3(50, 2.5f, 0), color),
		VertexFormat(corner + glm::vec3(40, -5, 0), color),
		VertexFormat(corner + glm::vec3(40, 0, 0), color),
		VertexFormat(corner, color)
	};

	Mesh* arow = new Mesh(name);
	std::vector<unsigned short> indices = { 0, 1, 2, 3, 4, 5, 6};
	arow->SetDrawMode(GL_LINE_LOOP);
	arow->InitFromData(vertices, indices);
	return arow;
}

Mesh* Object2D::CreateScore(std::string name, glm::vec3 color)
{	// creez "SCORE -"
	glm::vec3 corner = glm::vec3(0);

	std::vector<VertexFormat> vertices =
	{	// S
		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(10, 0, 0), color),
		VertexFormat(corner + glm::vec3(10, 10, 0), color),
		VertexFormat(corner + glm::vec3(0, 10, 0), color),
		VertexFormat(corner + glm::vec3(0, 20, 0), color),
		VertexFormat(corner + glm::vec3(10, 20, 0), color),
		// C
		VertexFormat(corner + glm::vec3(30, 0, 0), color),
		VertexFormat(corner + glm::vec3(20, 0, 0), color),
		VertexFormat(corner + glm::vec3(20, 20, 0), color),
		VertexFormat(corner + glm::vec3(30, 20, 0), color),
		// O
		VertexFormat(corner + glm::vec3(40, 0, 0), color),
		VertexFormat(corner + glm::vec3(40, 20, 0), color),
		VertexFormat(corner + glm::vec3(50, 20, 0), color),
		VertexFormat(corner + glm::vec3(50, 0, 0), color),
		// R
		VertexFormat(corner + glm::vec3(60, 0, 0), color),
		VertexFormat(corner + glm::vec3(60, 20, 0), color),
		VertexFormat(corner + glm::vec3(70, 20, 0), color),
		VertexFormat(corner + glm::vec3(70, 10, 0), color),
		VertexFormat(corner + glm::vec3(60, 10, 0), color),
		VertexFormat(corner + glm::vec3(70, 0, 0), color),
		// E
		VertexFormat(corner + glm::vec3(90, 0, 0), color),
		VertexFormat(corner + glm::vec3(80, 0, 0), color),
		VertexFormat(corner + glm::vec3(80, 20, 0), color),
		VertexFormat(corner + glm::vec3(90, 20, 0), color),
		VertexFormat(corner + glm::vec3(80, 10, 0), color),
		VertexFormat(corner + glm::vec3(90, 10, 0), color),
		// -
		VertexFormat(corner + glm::vec3(100, 10, 0), color),
		VertexFormat(corner + glm::vec3(110, 10, 0), color),

	};

	Mesh* score = new Mesh(name);
	std::vector<unsigned short> indices = {0, 1, 1, 2, 2,3, 3, 4, 4, 5,
											6, 7, 7, 8, 8 , 9,
											10, 11, 11, 12, 12, 13, 13, 10,
											14, 15, 15, 16, 16 , 17, 17, 18, 18, 19,
											20, 21, 21, 22, 22, 23, 24, 25,
											26, 27};


	score->SetDrawMode(GL_LINES);
	score->InitFromData(vertices, indices);
	return score;
}

Mesh* Object2D::CreateGameOver(std::string name, glm::vec3 color)
{	// creez "GAME OVER"
	glm::vec3 corner = glm::vec3(0);

	std::vector<VertexFormat> vertices =
	{	// G
		VertexFormat(corner + glm::vec3(10, 20, 0), color),
		VertexFormat(corner + glm::vec3(0, 20, 0), color),
		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(10, 0, 0), color),
		VertexFormat(corner + glm::vec3(10, 10, 0), color),
		VertexFormat(corner + glm::vec3(5, 10, 0), color),
		// A
		VertexFormat(corner + glm::vec3(20, 0, 0), color),
		VertexFormat(corner + glm::vec3(25, 20, 0), color),
		VertexFormat(corner + glm::vec3(30, 0, 0), color),
		VertexFormat(corner + glm::vec3(22.5, 10, 0), color),
		VertexFormat(corner + glm::vec3(27.5, 10, 0), color),
		// M
		VertexFormat(corner + glm::vec3(40, 0, 0), color),
		VertexFormat(corner + glm::vec3(42.5, 20, 0), color),
		VertexFormat(corner + glm::vec3(45, 10, 0), color),
		VertexFormat(corner + glm::vec3(47.5, 20, 0), color),
		VertexFormat(corner + glm::vec3(50, 0, 0), color),
		// E
		VertexFormat(corner + glm::vec3(70, 0, 0), color),
		VertexFormat(corner + glm::vec3(60, 0, 0), color),
		VertexFormat(corner + glm::vec3(60, 20, 0), color),
		VertexFormat(corner + glm::vec3(70, 20, 0), color),
		VertexFormat(corner + glm::vec3(60, 10, 0), color),
		VertexFormat(corner + glm::vec3(70, 10, 0), color),
		// O
		VertexFormat(corner + glm::vec3(90, 0, 0), color),
		VertexFormat(corner + glm::vec3(90, 20, 0), color),
		VertexFormat(corner + glm::vec3(100, 20, 0), color),
		VertexFormat(corner + glm::vec3(100, 0, 0), color),
		// V
		VertexFormat(corner + glm::vec3(110, 20, 0), color),
		VertexFormat(corner + glm::vec3(115, 0, 0), color),
		VertexFormat(corner + glm::vec3(120, 20, 0), color),
		// E
		VertexFormat(corner + glm::vec3(140, 0, 0), color),
		VertexFormat(corner + glm::vec3(130, 0, 0), color),
		VertexFormat(corner + glm::vec3(130, 20, 0), color),
		VertexFormat(corner + glm::vec3(140, 20, 0), color),
		VertexFormat(corner + glm::vec3(130, 10, 0), color),
		VertexFormat(corner + glm::vec3(140, 10, 0), color),
		// R
		VertexFormat(corner + glm::vec3(150, 0, 0), color),
		VertexFormat(corner + glm::vec3(150, 20, 0), color),
		VertexFormat(corner + glm::vec3(160, 20, 0), color),
		VertexFormat(corner + glm::vec3(160, 10, 0), color),
		VertexFormat(corner + glm::vec3(150, 10, 0), color),
		VertexFormat(corner + glm::vec3(160, 0, 0), color),

	};

	Mesh* game = new Mesh(name);
	std::vector<unsigned short> indices = {0, 1, 1, 2, 2, 3, 3, 4, 4, 5,
											6, 7, 7, 8, 9, 10,
											11, 12, 12, 13, 13, 14, 14, 15,
											16, 17, 17, 18, 18, 19, 20, 21,
											22, 23, 23, 24, 24, 25, 25, 22,
											26, 27, 27, 28,
											29, 30, 30, 31, 31, 32, 33, 34,
											35, 36, 36, 37, 37, 38, 38, 39, 39, 40};


	game->SetDrawMode(GL_LINES);
	game->InitFromData(vertices, indices);
	return game;
}

Mesh* Object2D::CreateHeart	(std::string name, glm::vec3 color)
{	// creez o inima
	glm::vec3 corner = glm::vec3(0);

	std::vector<VertexFormat> vertices =
	{	
		VertexFormat(corner + glm::vec3(5, 0, 0), color),
		VertexFormat(corner + glm::vec3(0, 16, 0), color),
		VertexFormat(corner + glm::vec3(10, 16, 0), color),

		VertexFormat(corner + glm::vec3(10 - 10 / 8, 20, 0), color),
		VertexFormat(corner + glm::vec3(7.5, 16, 0), color),

		VertexFormat(corner + glm::vec3(5 + 5 / 4, 20, 0), color),
		VertexFormat(corner + glm::vec3(5, 16, 0), color),

		VertexFormat(corner + glm::vec3(2.5, 16, 0), color),
		VertexFormat(corner + glm::vec3(5 - 5 / 4, 20, 0), color),
		VertexFormat(corner + glm::vec3(5/4, 20, 0), color),

	};

	Mesh* heart = new Mesh(name);
	std::vector<unsigned short> indices = {0, 1, 2, 2, 3, 4, 4, 3, 5, 5, 4, 6, 6, 7, 8, 7, 8, 9, 9, 7, 1};

	heart->SetDrawMode(GL_TRIANGLE_STRIP);
	heart->InitFromData(vertices, indices);
	return heart;
}

Mesh* Object2D::CreateNumber(std::string name, int number, glm::vec3 color)
{	// vreez numerele [0-9]
	glm::vec3 corner = glm::vec3(0);

	std::vector<VertexFormat> vertices = {};
	std::vector<unsigned short> indices = {};

	switch (number) {
		case 1:
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 0, 0), color));
			indices = std::vector<unsigned short>({0 , 1, 1, 2});
			break;
		case 2:
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 0, 0), color));
			vertices.push_back(VertexFormat(corner, color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 20, 0), color));
			indices = std::vector<unsigned short>({ 0 , 1, 1, 2, 2, 3, 3, 4, 4, 5});
			break;
		case 3:
			vertices.push_back(VertexFormat(corner, color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 0, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 10, 0), color));
			indices = std::vector<unsigned short>({ 0 , 1, 1, 2, 2, 3, 4, 5 });
			break;
		case 4:
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 0, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 20, 0), color));
			indices = std::vector<unsigned short>({ 0 , 1, 1, 2, 3, 4 });
			break;
		case 5:
			vertices.push_back(VertexFormat(corner, color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 0, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 20, 0), color));
			indices = std::vector<unsigned short>({ 0 , 1, 1, 2, 2, 3, 3, 4, 4, 5 });
			break;
		case 6:
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 20, 0), color));
			vertices.push_back(VertexFormat(corner, color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 0, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 10, 0), color));
			indices = std::vector<unsigned short>({ 0 , 1, 1, 2, 2, 3, 3, 4, 4, 5 });
			break;
		case 7:
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 20, 0), color));
			vertices.push_back(VertexFormat(corner , color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 10, 0), color));
			indices = std::vector<unsigned short>({ 0 , 1, 1, 2, 3, 4 });
			break;
		case 8:
			vertices.push_back(VertexFormat(corner, color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 0, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 10, 0), color));
			indices = std::vector<unsigned short>({ 0 , 1, 1, 2 , 2, 3, 3, 0, 4, 5});
			break;
		case 9:
			vertices.push_back(VertexFormat(corner, color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 0, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 10, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 10, 0), color));
			indices = std::vector<unsigned short>({ 0 , 1, 1, 2, 2, 3, 3, 4, 4, 5 });
			break;

		case 0:
			vertices.push_back(VertexFormat(corner, color));
			vertices.push_back(VertexFormat(corner + glm::vec3(0, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 20, 0), color));
			vertices.push_back(VertexFormat(corner + glm::vec3(10, 0, 0), color));
			indices = std::vector<unsigned short>({ 0 , 1, 1, 2, 2, 3, 3, 0});
			break;

		default:
			break;
	}

	Mesh* Mnumber = new Mesh(name);
	Mnumber->SetDrawMode(GL_LINES);
	Mnumber->InitFromData(vertices, indices);
	return Mnumber;
}
