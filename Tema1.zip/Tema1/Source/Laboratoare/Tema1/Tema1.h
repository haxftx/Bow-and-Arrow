#pragma once

#include <Component/SimpleScene.h>
#include <string>
#include <map> 
#include <Core/Engine.h>

#define MAX_SPEED 2.5f
#define LEN_SCORE 120
#define H_SCORE 20
#define SIZE_BOW 90
#define LEN_ARROW 50
#define H_ARROW 5
#define LEN_GAME 160
#define H_GAME 20
#define N_LIFE 3

typedef struct position {
	int x, y, size, type_ball;
	float scale;
} Tposition;

typedef struct positionArow {
	float x, y, px, py, angle, speed;
	int life;
} TArow;


class Tema1 : public SimpleScene
{
public:
	Tema1();
	~Tema1();

	void Init() override;

private:
	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;
	void FrameEnd() override;

	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnKeyRelease(int key, int mods) override;
	void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
	void OnWindowResize(int width, int height) override;
	void show_score(void);
	void show_arrow(float deltaTime);
	void show_shurikens(float deltaTime);
	void show_balls(float deltaTime);
	void show_player(float deltaTime);
	void set_default(void);

protected:
	glm::mat3 modelMatrix;
	glm::ivec2 resolution;
	float size_bow = 60;
	float size_obj = 20;
	float Time;
	bool flag;
	char go;
	int score;
	int start;
	float up;
	float angle;
	int n_life;
	float speed;
	float nextArow;
	int second;
	std::map <int, Tposition> balls;
	std::map <int, Tposition> shurikens;
	std::map <int, positionArow> arrows;
	Tposition player;
	TArow playerArow;
	Tposition pos;
};
#pragma once
