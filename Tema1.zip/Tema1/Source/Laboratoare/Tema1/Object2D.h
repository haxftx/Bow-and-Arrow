#pragma once

#include <string>
#include <include/glm.h>
#include <Core/GPU/Mesh.h>

namespace Object2D
{
	Mesh* CreateSquare(std::string name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill = false);
	Mesh* CreateBow(std::string name, glm::vec3 leftBottomCorner, float radius, glm::vec3 color);
	Mesh* CreateShuriken(std::string name, glm::vec3 leftBottomCorner, float size, glm::vec3 color);
	Mesh* CreateArow(std::string name);
	Mesh* CreateScore(std::string name, glm::vec3 color);
	Mesh* CreateGameOver(std::string name, glm::vec3 color);
	Mesh* CreateHeart(std::string name, glm::vec3 color);
	Mesh* CreateNumber(std::string name, int number, glm::vec3 color);
	Mesh* CreateBall(std::string name, glm::vec3 leftBottomCorner, float radius, glm::vec3 color);
	Mesh* CreatePoline(std::string name, glm::vec3 leftBottomCorner, float radius, glm::vec3 color);
}

#pragma once
