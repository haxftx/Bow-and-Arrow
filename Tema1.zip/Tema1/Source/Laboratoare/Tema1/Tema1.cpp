#include "Tema1.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"
#include "Object2D.h"
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#include <ctime>


using namespace std;

Tema1::Tema1()
{
}

Tema1::~Tema1()
{
}

void Tema1::set_default() { // setez valorile default
	Time = NULL;
	second = 6;
	player.x = 40;
	player.y = SIZE_BOW / 2;
	player.size = size_bow;
	playerArow.x = player.x;
	playerArow.y = player.y;
	playerArow.angle = NULL;
	playerArow.speed = NULL;
	nextArow = NULL;
	speed = NULL;
	n_life = N_LIFE;
	up = NULL;
	score = NULL;
	go = NULL;
	flag = 1;
	balls.clear();
	shurikens.clear();
	arrows.clear();

}

void Tema1::Init()
{
	resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	glm::vec3 corner = glm::vec3(0, 0, 0);

	set_default();
	// creez toate Meshurile si le adaug in lista
	Mesh* square = Object2D::CreateSquare("square", corner, 20, glm::vec3(0.5, 0.5, 0.75), true);
	AddMeshToList(square);
	Mesh* pow = Object2D::CreateSquare("pow", corner, size_obj, glm::vec3(1, 1, 0), true);
	AddMeshToList(pow);
	Mesh* bow = Object2D::CreateBow("bow", corner, size_bow, glm::vec3(1, 0, 0));
	AddMeshToList(bow);
	Mesh* ball1 = Object2D::CreateBall("ballR", corner, size_obj, glm::vec3(1, 0, 0));
	AddMeshToList(ball1);
	Mesh* ball2 = Object2D::CreateBall("ballY", corner, size_obj, glm::vec3(1, 1, 0));
	AddMeshToList(ball2);
	Mesh* poline = Object2D::CreatePoline("poline", corner, size_obj, glm::vec3(1, 1, 1));
	AddMeshToList(poline);
	Mesh* shuriken = Object2D::CreateShuriken("shuriken", corner, size_obj, glm::vec3(0.5f, 0.5f, 0.5f));
	AddMeshToList(shuriken);
	Mesh* arow = Object2D::CreateArow("arow");
	AddMeshToList(arow);
	Mesh* heart = Object2D::CreateHeart("heart", glm::vec3(1, 0, 0));
	AddMeshToList(heart);
	Mesh* score = Object2D::CreateScore("score", glm::vec3(1, 0, 0));
	AddMeshToList(score);
	Mesh* game = Object2D::CreateGameOver("game", glm::vec3(0, 0, 1));
	AddMeshToList(game);
	for (int i = 0; i < 10; i++) {
		std::string s = std::to_string(i);
		Mesh* number = Object2D::CreateNumber(s, i, glm::vec3(1, 0, 0));
		AddMeshToList(number);
	}

}

void Tema1::FrameStart()
{

	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Tema1::show_score() {

	// cifrele se tranlateaza dupa "SCORE - "
	int x = score, i = (std::to_string(score)).size() - 1;
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(1, resolution.y - H_SCORE - 2);
	RenderMesh2D(meshes["score"], shaders["VertexColor"], modelMatrix);

	if (score == 0) { // scorul 0
		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(LEN_SCORE + 1, resolution.y - H_SCORE - 2);
		RenderMesh2D(meshes["0"], shaders["VertexColor"], modelMatrix);
	} else {
		while (x > 0) { // afisez fiecare cifra din scor
			modelMatrix = glm::mat3(1);
			std::string s = std::to_string(x % 10);
			modelMatrix *= Transform2D::Translate(LEN_SCORE + 1 + size_obj * i, resolution.y - H_SCORE - 2);
			RenderMesh2D(meshes[s], shaders["VertexColor"], modelMatrix);
			if (x == 0)
				break;
			x /= 10;
			i--;
		}
	}
	for (i = n_life; i > 0; i--) { // afisez vietile
		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(resolution.x - size_obj * i, resolution.y - H_SCORE - 2);
		RenderMesh2D(meshes["heart"], shaders["VertexColor"], modelMatrix);
	}
	// marginea unde e powbar si scorul impreuna cu vietile
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(0, resolution.y - H_SCORE - 4) * Transform2D::Scale(100.f, 1.5f);
	RenderMesh2D(meshes["square"], shaders["VertexColor"], modelMatrix);
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Scale(1.5f, 70.f);
	RenderMesh2D(meshes["square"], shaders["VertexColor"], modelMatrix);
}

void Tema1::show_player(float deltaTime) {
	
	// afisez arcul
	player.y = up + SIZE_BOW / 2;
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(player.x, player.y)*Transform2D::Scale(0.5f, 0.75f)*Transform2D::Rotate(angle);
	RenderMesh2D(meshes["bow"], shaders["VertexColor"], modelMatrix);

	// afisez bara de tragere
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Scale(0.5f, speed);
	RenderMesh2D(meshes["pow"], shaders["VertexColor"], modelMatrix);
	if (go) { // daca trag cu o gaseata
		
		if (nextArow == 0 && speed > 0.f) { // setez datele sagetii
			playerArow.speed = speed;
			playerArow.life = N_LIFE;
			playerArow.angle = angle;
			playerArow.px = player.x;
			playerArow.py = player.y;
			//adaug sageata
			arrows.insert(pair<int, positionArow>(arrows.size(), playerArow));
		}

		nextArow += playerArow.speed;
		speed = NULL;
		if (nextArow > LEN_ARROW) { // dupa ce depaseste sageata dimensiune unei sageti pot trage alta
			nextArow = 0;
			go = 0;
			return;
		}
		
	} else { // sageata de pe arc
		playerArow.y = up + SIZE_BOW / 2;
		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(playerArow.x, playerArow.y) * Transform2D::Rotate(angle);
		RenderMesh2D(meshes["arow"], shaders["VertexColor"], modelMatrix);
	}
}

void Tema1::show_shurikens(float deltaTime) {

	if ((int)Time % second == 0) { // la fiecare second secunde creez un nou shuriken
		Time += 1;
		srand(time(0));
		pos.x = resolution.x + 2 * size_obj;
		pos.y = (rand() % rand() % rand() % rand ()) % (resolution.y - 80) + 30;
		pos.size = size_obj;
		pos.scale = 0.f;
		shurikens.insert(pair<int, Tposition>(shurikens.size(), pos));
	}
	for (int i = 0; i < shurikens.size(); i++) {// pentru fiecare obiect
		// il afisez si-i actualizez datele
		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(shurikens[i].x, shurikens[i].y) * Transform2D::Rotate(3 * Time);
		modelMatrix *= Transform2D::Scale(1.f - shurikens[i].scale, 1.f - shurikens[i].scale);
		shurikens[i].x -= deltaTime;
		shurikens[i].scale += shurikens[i].scale;
		RenderMesh2D(meshes["shuriken"], shaders["VertexColor"], modelMatrix);

		if (shurikens[i].x == 0 || 1.f - shurikens[i].scale < 0.f) { // daca iese din ecran il sterg sau e scalat cu 0
			shurikens.erase(i);
		}
		// colliziune intre shuriken si arc
		if (player.size + shurikens[i].size - player.size / 4 > 
			sqrt(pow(player.x - shurikens[i].x, 2) + pow(player.y - shurikens[i].y, 2))) {
			n_life--;
			shurikens.erase(i);
		}
	}


}

void Tema1::show_balls(float deltaTime) {

	if ((int)Time % second == 0) {// la fiecare second secunde creez un nou balon
		srand(time(0));
		pos.y = -2 * size_obj;
		pos.x = (rand() % rand() % rand()) % (resolution.x - 200) + 190;
		pos.size = size_obj;
		pos.scale = 0.f;
		srand(time(0));
		pos.type_ball = rand() % 2;
		balls.insert(pair<int, Tposition>(balls.size(), pos));
	}
	for (int i = 0; i < balls.size(); i++) { // pentru fiecare obiect
		modelMatrix = glm::mat3(1);
		modelMatrix *= Transform2D::Translate(balls[i].x, balls[i].y) * Transform2D::Scale(0.75f, 1.f);
		modelMatrix *= Transform2D::Scale(1.f - balls[i].scale, 1.f - balls[i].scale);
		balls[i].y += 60 * deltaTime;
		balls[i].scale += balls[i].scale;

		if (balls[i].type_ball == 0)
			RenderMesh2D(meshes["ballR"], shaders["VertexColor"], modelMatrix);
		else RenderMesh2D(meshes["ballY"], shaders["VertexColor"], modelMatrix);
		RenderMesh2D(meshes["poline"], shaders["VertexColor"], modelMatrix);
		if (balls[i].y == resolution.y || 1.f - balls[i].scale < 0.f) { // daca iese din ecran sau scalez cu 0
			balls.erase(i);
		}
	}
}

void Tema1::show_arrow(float deltaTime) {

	for (int i = 0; i < arrows.size(); i++) {
		if (arrows[i].speed == 0.f) { // daca viteza e 0 inseamna ca nu se deelaseaza si nu o afisez
			continue;
		}
		arrows[i].x += arrows[i].speed; // x-l creste cu viteza, y-l in dependeta de x sub unghi
		arrows[i].y = tan(arrows[i].angle) * (arrows[i].x - arrows[i].px) + arrows[i].py;
		
		modelMatrix = glm::mat3(1);//afisez sageata
		modelMatrix *= Transform2D::Translate(arrows[i].x, arrows[i].y) * Transform2D::Rotate(arrows[i].angle);
		RenderMesh2D(meshes["arow"], shaders["VertexColor"], modelMatrix);
		
		// coleziunea se face dupa varful sagetii si aria de incadrare a obiectului
		// verific daca nu sunt coliziuni cu baloanele sau shurikene
		for (int j = 0; j < shurikens.size(); j++) {
			if (pow((float)((float)arrows[i].x + cos(arrows[i].angle) * LEN_ARROW - (float)shurikens[j].x), 2) +
				pow(tan(arrows[i].angle) * ((arrows[i].x + cos(arrows[i].angle) * LEN_ARROW)- arrows[i].px) +
					arrows[i].py - shurikens[j].y, 2) <= pow(shurikens[j].size, 2) && shurikens[j].scale == 0.f) {
				score += 3;
				shurikens[j].scale = deltaTime;
				arrows[i].life = 0;
			}
		}
		if (arrows[i].life == 0) { // daca nu mai are vieti sterg sageata
			arrows.erase(i);
			continue;
		}
		for (int j = 0; j < balls.size(); j++) {
			if (pow((float)((float)arrows[i].x + cos(arrows[i].angle) * LEN_ARROW - (float)balls[j].x), 2) +
				pow(tan(arrows[i].angle) * ((arrows[i].x + (float)cos(arrows[i].angle) * LEN_ARROW) - arrows[i].px) +
					arrows[i].py - balls[j].y, 2) <= pow(balls[j].size, 2) && balls[j].scale == 0.f) {
				if (balls[j].type_ball == 0)
					score += 2;
				else score = max(score - 1, 0);
				arrows[i].life--;
				balls[j].scale = deltaTime;
			}
		}
		if (arrows[i].x > resolution.x || arrows[i].life == 0) // daca iese din ecran o sterg sau nu mai are vieti
			arrows.erase(i);

	}
}

void Tema1::Update(float deltaTimeSeconds)
{
	if (n_life) { // cat jucatorul are vieti
		Time += deltaTimeSeconds;
		show_player(deltaTimeSeconds);
		show_score();
		show_balls(deltaTimeSeconds);
		show_shurikens(deltaTimeSeconds);
		show_arrow(deltaTimeSeconds);
		start = 0;
	} else { // afisez GAME OVER
		modelMatrix = glm::mat3(1);
		int coeficient = resolution.x / (LEN_GAME + 1);
		modelMatrix *= Transform2D::Translate((resolution.x - LEN_GAME*coeficient)/2, (resolution.y - H_GAME*coeficient)/2);
		modelMatrix *= Transform2D::Scale(coeficient, coeficient);
		RenderMesh2D(meshes["game"], shaders["VertexColor"], modelMatrix);
		if (start)
			set_default();
	}
}

void Tema1::FrameEnd()
{

}


void Tema1::OnInputUpdate(float deltaTime, int mods)
{
	
	if (window->KeyHold(GLFW_KEY_W) && up < resolution.y - H_SCORE - 4 - SIZE_BOW) {
		up += 100 * deltaTime;
	}
	if (window->KeyHold(GLFW_KEY_S) && up > 0) {
		up -= 100 * deltaTime;
	}
	if (window->MouseHold(GLFW_MOUSE_BUTTON_LEFT)) { // viteza
		if (speed > MAX_SPEED && flag) {
			flag = 0;
		}
		if (speed <= 0.f && !flag) {
			flag = 1;
		}
		if (flag)
			speed += deltaTime;
		else speed -= deltaTime;
	}
}

void Tema1::OnKeyPress(int key, int mods)
{
	// add key press event
	if (key == GLFW_KEY_P) { // play
		start = 1;
	}
	if (key == GLFW_KEY_1 && second < 10) {
		second++;
	}
	if (key == GLFW_KEY_2 && second > 2) {
		second--;
	}
}

void Tema1::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	angle = -atan2((mouseY - (resolution.y - SIZE_BOW / 2 - H_ARROW / 2 - up)) ,(mouseX - SIZE_BOW / 2));
	// add mouse move event
}

void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{	
	
	// add mouse button press event
}

void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_2) {
		go = 1;
	}
	// add mouse button release event
}

void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema1::OnWindowResize(int width, int height)
{
	resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);
	
}
